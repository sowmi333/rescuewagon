<div class="alert alert-warning alert-with-icon" data-notify="container">
                    <div class="container">
                        <div class="alert-wrapper">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <i class="nc-icon nc-simple-remove"></i>
                            </button>
                            <div class="message"><i class="nc-icon nc-bell-55"></i> This is a notification with close button and icon.</div>
                            <button type="button" class="btn btn-danger btn-round cancel">Round</button>
                        </div>
                    </div>
                </div>
